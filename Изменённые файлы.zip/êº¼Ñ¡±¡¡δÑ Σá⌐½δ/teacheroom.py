"Класс имени преподавателя и аудитории"""
from dateclass import Date
import re
from memory_profiler import profile
class TeacherRoom:
    """Класс для представления аудитории и имени преподавателя."""
    @profile
    def __init__(self):
        """Класс для представления аудитории и имени преподавателя"""
        self.date = Date()
        self.room = None
        self.teacher = None

    @profile
    def check_room(self, room):
        """Проверяет корректность формата аудитории."""
        pattern = r"\d+-\d+"
        if not re.match(pattern, room):
            raise ValueError("Неверный формат аудитории (верный: этаж-кабинет)")

    @profile
    def check_teacher(self, teacher):
        """Проверяет корректность имени преподавателя."""
        pattern = r"[A-Za-z]+\.[A-Z]\.[A-Z]"
        if not re.match(pattern, teacher):
            raise ValueError("Неверный формат имени преподавателя (верный:\
                Фамилия.И.О. и на латинице)")

    @profile
    def read(self, string):
        """Читает данные из строки и обновляет атрибуты экземпляра."""
        try:
            result = string.split()
            self.date.read_date(result[0])
            self.check_room(result[1])
            self.check_teacher(result[2])
            self.room = result[1]
            self.teacher = result[2]
        except IndexError as error:
            print("Ошибка прочтения файла: недостаточно данных.")
            raise RuntimeError("Недостаточно данных в строке для чтения.") from error
    @profile
    def print_teacherroom(self):
        """Печатает информацию о преподавателе и аудитории."""
        print(".".join([str(self.date.year), str(self.date.month),\
            str(self.date.day)]), self.room, self.teacher)
