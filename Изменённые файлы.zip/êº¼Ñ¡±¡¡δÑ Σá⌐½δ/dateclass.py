"""Класс даты"""
import re
from memory_profiler import profile
class Date:
    """Класс для представления даты с проверкой формата и значения."""
    @profile
    def __init__(self):
        self.year = None
        self.month = None
        self.day = None
        self.date_join = None
    @profile
    def check_date(self, date):
        """Проверяет корректность формата даты (гггг.мм.дд)."""
        date_pattern = r"\d{4}\.\d{2}\.\d{2}$"
        match = re.match(date_pattern, date)
        if not match:
            raise ValueError("Неверный формат даты (верный: гггг.мм.дд)")

        year, month, day = map(int, date.split("."))
        if not 1 <= month <= 12 or not 1 <= day <= 31:
            raise ValueError("Неверное значение месяца или дня.")

        if (month in [4, 6, 9, 11] and day > 30) or (month == 2 and day > \
            (29 if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0) else 28)):
            raise ValueError("Неверное количество дней в месяце для указанной даты.")
    @profile
    def date_join_method(self):
        """Формирует строку даты для импорта."""
        self.date_join = ".".join([str(self.year).zfill(4), str(self.month).zfill(2),\
            str(self.day).zfill(2)])

    @profile
    def read_date(self, date):
        """Читает дату из строки, проверяет её и устанавливает соответствующие атрибуты."""
        self.check_date(date)
        date_elems = date.split(".")
        self.year, self.month, self.day = map(int, date_elems)
        self.date_join_method()
