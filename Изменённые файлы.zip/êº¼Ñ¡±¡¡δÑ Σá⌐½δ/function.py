"""Функция для прочтения исключений и их проверка"""
from memory_profiler import profile
class EmptyDocumentError(Exception):
    """Исключение возникает когда документ пуст"""
class EmptyRecordListError(Exception):
    """Исключение возникает когда список записей пуст"""
@profile
def open_document(file_path):
    """Открываем файл, если пустой файл или иного формата, то ошибка"""
    if not file_path.endswith(".txt"):
        raise ValueError("Необходим формат файла .txt")
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    if not lines:
        raise EmptyDocumentError("Документ не может быть пустым")
    return lines
@profile
def parse_records(obj, lines) -> list:
    """Образует список объектов и если строку невозможно обработать, то ошибка"""
    records = []
    for string in lines:
        try:
            ed_room = obj()
            ed_room.read(string)
            records.append(ed_room)
        except TypeError as error:
            print(f"Невозможно обработать файл: {error}")
            raise
    return records
@profile
def display_agenda(rec_list):
    """Отображает список записей и вызов, если список пуст"""
    if not rec_list:
        raise EmptyRecordListError("Список записей пуст")

    for elem in rec_list:
        try:
            elem.print_teacherroom()
        except AttributeError as error:
            print(f"Ошибка ввода данных: {repr(error)}")
            raise
