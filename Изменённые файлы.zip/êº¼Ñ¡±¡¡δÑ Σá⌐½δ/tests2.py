"""Тесты входа данных"""
import unittest
import function
class TestCaseNom2(unittest.TestCase):
    """Тестирование при помощи unittest"""
    def test_format(self):
        """Проверка файла неверного формата"""
        self.assertRaises(ValueError, function.open_document, "file.doc")
    def test_empty(self):
        """Проверяет файл на пустые"""
        self.assertRaises(Exception, function.open_document, "empty.txt")
    def test_none(self):
        """Проверяет нулевые значения"""
        none_file = None
        lines = ["2023.10.01 3-21 Malyalik.L.O.", "2023.10.02 4-56 Bananov.Q.T."]
        with self.assertRaises(TypeError):
            function.parse_records(none_file, lines)
    def test_print_entire_schedule(self):
        """Проверяет неподходящие входные данные"""
        none_spisok = [None, None]
        none_list = []
        self.assertRaises(AttributeError, function.display_agenda, none_spisok)
        self.assertRaises(Exception, function.display_agenda, none_list)
if __name__ == '__main__':
    unittest.main()
