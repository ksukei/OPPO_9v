"""Основная функция"""
from teacheroom import TeacherRoom
import function
import cProfile
def main():
    """Основная функция, которая инициализирует процесс открытия"""
    function.display_agenda(
        function.parse_records(TeacherRoom, function.open_document('in.txt')))
if __name__ == '__main__':
    main()
cProfile.run("main()")
