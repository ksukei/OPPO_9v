"""Тесты входных данных: дата, коаудитория, преподаватель"""
import unittest
from teacheroom import TeacherRoom
from dateclass import Date
class TestCase(unittest.TestCase):
    """Тесты для проверки входных данных"""
    def test_date(self):
        """Тестирование формата даты"""
        validator_1 = "2023/00/01"
        validator_2 = "00.00.123"
        object_0 = Date()
        with self.assertRaises(Exception):  # Проверяем, что данные вызывают исключение
            object_0.check_date(validator_1)
        with self.assertRaises(Exception):
            object_0.check_date(validator_2)
    def test_name(self):
        """Тестирование имени преподавателя"""
        validator = "Тудакин.ИП"
        object_1 = TeacherRoom()
        with self.assertRaises(Exception):  # Проверяем, что данные вызывают исключение
            object_1.check_teacher(validator)
    def test_room(self):
        """Тестирование номера аудитории"""
        validator = "ABC"
        object_2 = TeacherRoom()
        with self.assertRaises(Exception):  # Проверяем, что данные вызывают исключение
            object_2.check_room(validator)
if __name__ == '__main__':
    unittest.main()
